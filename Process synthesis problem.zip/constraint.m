function [g,geq]=constraint(x)
% Inequality constraints

g(1)=-x(1).^2-x(2)+1.25;
g(2)=x(1)+x(2)-1.6;


% If no equality constraint at all, put geq=[] as follows
geq=[];