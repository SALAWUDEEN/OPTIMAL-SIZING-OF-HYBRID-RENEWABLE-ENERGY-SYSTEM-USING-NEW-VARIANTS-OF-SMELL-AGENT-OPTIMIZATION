function z=Fun(fhandle,fnonlin,u)
% Objective
z=fhandle(u);

% Apply nonlinear constraints by the penalty method
% Z=f+sum_k=1^N lam_k g_k^2 *H(g_k) where lam_k >> 1 
z=z+getconstraints(fnonlin,u);